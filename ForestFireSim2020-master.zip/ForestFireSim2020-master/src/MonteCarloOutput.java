public class MonteCarloOutput {
    public static void main(String[] args) {
        // A non-graphical runner for doing a lot
        // of simulations and displaying the results

        // You'd run this if you wanted to run, say 1000 trials for
        // a set of initial conditions and see the results.
    }
}
