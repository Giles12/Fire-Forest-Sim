
public class Simulator {
    // TODO: declare your 2d array for the forest
    // TODO: declare any other attributes you need at the top

    /***
     * Create a new simulator.  The simulator creates a new Forest of size (r, c).
     *
     * @param r
     * @param c
     */
    public Simulator(int r, int c) {
        // TODO: initialize all your attributes here!
    }

    // TODO: add methods outlines in assignment sheet
    // * way to get statistical information about the current state of the simulation
    // * way to run simulation for one step
    // * way to do a "full run" of running until fires are burned out
    // * way to (re-)initialize your forest with particular tree density
    //

    public int getWidth() {
        return 1;   // TODO: change this once you make a grid variable
    }

    public int getHeight() {
        return 1;   // TODO: change this once you make a grid variable
    }

    public int[][] getDisplayGrid() {
        return new int[0][];    // TODO: change this to return your grid variable
    }
}